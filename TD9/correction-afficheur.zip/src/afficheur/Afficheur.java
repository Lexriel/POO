/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 
 */

public class Afficheur {

   protected char[] message;
   protected Decaleur decaleur;
   protected int indexCourant;  // pour retenir � quel caract�re du message on est arriv�

   /**
    * 
    */
   public Afficheur(int tailleAffichage) {
      this.decaleur = new Decaleur(tailleAffichage);
   }

   public void setMessage(String message) {      
      this.message = message.toCharArray();
      this.indexCourant = 0;
   }

   public void top() {
      this.decaleur.decale(this.message[this.indexCourant]);
      this.indexCourant = (this.indexCourant + 1) % this.message.length;
   }

   public String toString() {
      return this.decaleur.toString();
   }

}
