/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 * 
 * TODO
 */

public class Decaleur {

   private char[] texte;

   public Decaleur(int largeur) {
      this.texte = new char[largeur];
      this.raz();
   }


   public void raz() {
      for (int i = 0; i < this.texte.length; i++) {
         this.texte[i] = ' ';
      }
   }

   public void decale(char car) {
      for (int i = 0; i < this.texte.length-1; i++) {
         this.texte[i] = this.texte[i+1];
      }
      this.texte[this.texte.length - 1] = car;
   }

   public String toString() {
      return new String(this.texte);
   }

}
