/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 * 
 * TODO
 */

public class Horloge {

   public void tester(Afficheur afficheur) {
      String message = "Abcd";
      afficheur.setMessage(message);
      for (int i = 0; i < 10; i++) {
         afficheur.top();
         System.out.println("|" + afficheur + "|");
      }
   }

   public static void main(String[] args) {
      Horloge t = new Horloge();
      t.tester(new Afficheur(5));
      System.out.println("*********************************");
      t.tester(new Latence(5,3));
      System.out.println("*********************************");
      t.tester(new Vitesse(5,3,2));

   }
}
