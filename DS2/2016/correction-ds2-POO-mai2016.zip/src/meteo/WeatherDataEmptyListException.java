package meteo;

public class WeatherDataEmptyListException extends Exception {

	public WeatherDataEmptyListException(String message) {
		super(message);
	}

}
