package colis;

public class Adresse {

}
