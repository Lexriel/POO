public class For2
{ public static void main (String args[])
  { int i ;
    i = 1 ;
    while (i <= 5)
     { System.out.print ("bonjour ") ;
       System.out.println (i + " fois") ;
       i++ ;
     }
  }
}


