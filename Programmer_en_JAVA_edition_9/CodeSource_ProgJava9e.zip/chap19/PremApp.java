import javax.swing.* ;
public class PremApp extends JApplet
{  public PremApp ()
   {
   }
}


