import java.awt.* ;
import javax.swing.* ;
public class Appletx extends JApplet
{   public Appletx ()
    { System.out.println ("const") ;     Clavier.lireInt();
    }
    public void init()
    { System.out.println ("init") ; Clavier.lireInt() ;
    }
}


