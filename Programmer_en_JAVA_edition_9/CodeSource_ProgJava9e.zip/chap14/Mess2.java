import javax.swing.* ;
import javax.swing.* ;
public class Mess2
{ public static void main (String args[])
  { System.out.println ("avant message") ;
    JOptionPane.showMessageDialog(null, "Hello");
    System.out.println ("apres message") ;
  }
}

