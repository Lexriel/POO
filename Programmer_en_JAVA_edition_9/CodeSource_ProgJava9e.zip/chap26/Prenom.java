public class Prenom 
{ public Prenom ()
 { prenom = "" ;
 }
 public void setPrenom (String pr)
 { prenom = pr ; 
 }
 public String getPrenom () 
 { return prenom ;
 }  
 String prenom ;
}
