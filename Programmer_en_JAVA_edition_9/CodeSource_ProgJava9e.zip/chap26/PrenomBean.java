package beans ;
public class PrenomBean 
{ public PrenomBean ()
 { prenom = "" ;
 }
 public void setPrenom (String pr)
 { prenom = pr ; 
 }
 public String getPrenom () 
 { return prenom ;
 }  
 String prenom ;
}
