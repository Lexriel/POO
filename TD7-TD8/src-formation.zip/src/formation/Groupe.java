
package formation;

import java.util.*;

/**
 * Classe Groupe : d�finition d'un groupe d'�tudiants d'une m�me formation par
 * un tableau associatif dont la cl� est le NIP de l'�tudiant.
 */
public class Groupe {
	/** son nom */
	private String sonNom;
	/** ses �tudiants */
	private Set<Etudiant> sesEtudiants;
	/** le nom de sa formation */
	private Formation formation;

	/**
	 * Construit un groupe vide dont le nom et le nom de la formation sont
	 * pass�s en param�tre.
	 */
	public Groupe(String nom, Formation Formation) {
		this.sesEtudiants = new HashSet<Etudiant>();
		this.formation = Formation;
		this.sonNom = nom;
	}

	/**
	 * Ajoute l'�tudiant pass� en param�tre au groupe, *
	 * 
	 * @param e
	 *            l'�tudiant � ajouter au groupe.
	 */
	public void ajoutEtudiant(Etudiant e) {
		this.sesEtudiants.add(e);
	}

	/**
	 * Supprime l'�tudiant pass� en param�tre du groupe, s'il est pr�sent.
	 * 
	 * @param e
	 *            l'�tudiant � supprimer du groupe.
	 * @throws IllegalStateException
	 *             si l'�tudiant n'appartient pas au groupe.
	 */
	public void suppressionEtudiant(Etudiant e) {
		this.sesEtudiants.remove(e);
	}

	/**
	 * retourne un iterateur sur ce groupe.
	 * 
	 * @return un it�rateur permettant de parcourir ce groupe.
	 */
	public Iterator<Etudiant> iterator() {
		return sesEtudiants.iterator();
	}

	/**
	 * Calcule la moyenne du groupe pour la mati�re dont le nom est pass� en
	 * param�tre.
	 * 
	 * @param matiere
	 *            le nom de la matiere
	 * @return la moyenne du groupe pour la mati�re dont le nom est pass� en
	 *         param�tre.
	 */
	public float moyenneMatiere(Matiere matiere) {
		float somme = 0;
		for (Etudiant etudiant : this.sesEtudiants)
			try {
				somme += etudiant.moyenneMatiere(matiere);
			} catch (IllegalStateException e) {
			}
		return somme / this.sesEtudiants.size();
	}

	/**
	 * Retourne une liste des �tudiants tri�s selon un,comparateur fourni
	 *  @param comp le comparateur utilis� pour le tri
	 *  @return la liste des �tudiants de ce groupe tri�e selon le compaarateur fourni
	 */
	private List<Etudiant> tri(Comparator<Etudiant> comp) {
		List<Etudiant> listeEtud = new LinkedList<Etudiant>(sesEtudiants);
		// trie selon l'ordre croissant induit par le comparator en param�tre
		Collections.sort(listeEtud, comp);
		return listeEtud;
	}

	/**
	 * Retourne une liste des �tudiants tri�s sur leur nom par ordre
	 * alphab�tique croissant.
	 */
	public List<Etudiant> triAlphabetique() {
		return this.tri(new ComparateurNom());
	}
	/**
	 * Retourne une liste des �tudiants tri�s par m�rite (selon l'ordre de leur
	 * moyenne g�n�rale d�croissante).
	 */
	public List<Etudiant> triParMerite() {
		return this.tri(new ComparateurMoyGale());
	}
	
}