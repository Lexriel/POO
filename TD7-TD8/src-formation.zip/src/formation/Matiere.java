package formation;
/** les mati�res enseign�es, �num�ration � compl�ter si besoin */
public enum Matiere {
	ASD, AEL, POO, TW;
}
