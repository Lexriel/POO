package formation;

import java.util.*;

/**
 * Classe ComparateurNom : comparateur d�finissant qu'un �tudiant est plus petit
 * qu'un autre si son nom est plus petit pour l'ordre alphab�tique.
 */
public class ComparateurNom implements Comparator<Etudiant> {

	public int compare(Etudiant e1, Etudiant e2) {
		return e1.nom().compareTo(e2.nom());
	}
}