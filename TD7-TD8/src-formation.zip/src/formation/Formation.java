package formation;

import java.util.*;

/**
 * Classe Formation : formation d'un �tudiant, d�finie par un identifiant, et
 * une liste de couples (mati�re, coeff) implant�e par une Map. La cl� de ce
 * tableau associatif est le nom de la mati�re, de type Matiere qui est une
 * �num�ration, l'objet associ� est son coefficient (un entier).
 */
public class Formation {
	/** son nom. */
	private String sonNom;
	/**
	 * ses mati�res.
	 */
	private Map<Matiere, Integer> sesMatieres;

	/**
	 * Construit une formation dont l'identifiant est pass� en param�tre.
	 * 
	 * @param nom
	 *            le nom de cette formation
	 */
	public Formation(String nom) {
		this.sonNom = nom;
		this.sesMatieres = new HashMap<Matiere, Integer>();
	} // Formation

	/*************** ACCESSEURS EN LECTURE ***************************/

	/**
	 * retourne le coefficient de la mati�re dont le nom est pass� en param�tre.
	 * 
	 * @param matiere
	 *            le nom de la mati�re dont on veut le coefficient
	 * @return le coefficient de la mati�re dont le nom est pass� en param�tre
	 * @throws IllegalStateException
	 *             si la mati�re n'existe pas
	 */
	public int coeffMatiere(Matiere matiere) throws IllegalStateException {
		if (this.matiereExiste(matiere))
			return this.sesMatieres.get(matiere);
		else {
			throw new IllegalStateException("la matiere " + matiere
					+ " n'existe pas ds la formation " + this.sonNom);
		}
	}

	/**
	 * retourne le nom de cette formation.
	 * 
	 * @return le nom de cette formation.
	 */
	public String getNom() {
		return this.sonNom;
	}

	/**
	 * retourne l'ensemble des matieres de cette formation.
	 * 
	 * @return l'ensemble des mati�res de cette formation.
	 */
	public Set<Matiere> matieres() {
		return this.sesMatieres.keySet();
	}

	/**
	 * retourne vrai si la mati�re dont le nom est pass� en param�tre appartient
	 * � cette formation.
	 * 
	 * @param matiere
	 *            le nom de cette mati�re
	 */
	public boolean matiereExiste(Matiere matiere) {
		return this.sesMatieres.containsKey(matiere);
	}

	/******************** MODIFICATEURS ******************/

	/**
	 * Ajoute � cette formation une mati�re dont le nom et le coefficient sont
	 * pass�s en param�tre, si elle n'est pas d�j� pr�sente.
	 * 
	 * @param matiere
	 *            le nom de la matiere
	 * @param coeff
	 *            le coefficient de cette mati�re
	 * @throws IllegalStateException
	 *             si la mati�re existe d�j�
	 */
	public void ajoutMatiere(Matiere matiere, int coeff)
			throws IllegalStateException {
		// on regarde si la mati�re existe
		if (this.matiereExiste(matiere))
			throw new IllegalStateException("la matiere " + matiere
					+ " existe d�j� ds la formation " + this.sonNom);
		else
			this.sesMatieres.put(matiere, coeff);
	} // ajoutMatiere()

	/**
	 * Modifie ds cette formation le coefficient associ� � la mati�re dont le
	 * nom est pass� en param�tre.
	 * 
	 * @param matiere
	 *            le nom de cette mati�re
	 * @param coeff
	 *            le coefficient de cette mati�re
	 * @throws IllegalStateException
	 *             si la mati�re n'existe pas
	 */
	public void modifCoeff(Matiere matiere, int coeff)
			throws IllegalStateException {
		if (this.matiereExiste(matiere))
			this.sesMatieres.put(matiere, coeff);
		else
			throw new IllegalStateException("la matiere " + matiere
					+ " n'existe pas ds la formation " + this.sonNom);
	}

	/**
	 * Supprime de cette formation la mati�re dont le nom est pass� en
	 * param�tre.
	 * 
	 * @param matiere
	 *            le nom de la mati�re � supprimer
	 * @throws IllegalStateException
	 *             si la mati�re n'existe pas
	 */
	public void suppressionMatiere(Matiere matiere)
			throws IllegalStateException {
		if (this.matiereExiste(matiere))
			this.sesMatieres.remove(matiere);
		else
			throw new IllegalStateException("la matiere " + matiere
					+ " n'existe pas ds la formation " + this.sonNom);
	}

	/********************* POUR AFFICHAGE ******************************/

	/**
	 * retourne une version String de cette formation.
	 * 
	 * @return une version String de cette formation.
	 */
	public String toString() {
		return new String("Formation " + this.sonNom + " : "
				+ this.sesMatieres.toString());
	}

	public static void main(String[] arg) {
		Formation f = new Formation("licence");
		f.ajoutMatiere(Matiere.ASD, 3);
		System.out.println(f.toString());
		f.ajoutMatiere(Matiere.POO, 3);
		System.out.println(f.toString());
		f.modifCoeff(Matiere.POO, 4);
		System.out.println("PO : " + f.coeffMatiere(Matiere.POO));
		System.out.println("ASD : " + f.coeffMatiere(Matiere.ASD));
		System.out.println(f.toString());
	}

}
